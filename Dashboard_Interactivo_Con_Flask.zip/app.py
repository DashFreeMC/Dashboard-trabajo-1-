
from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

# Ruta principal
@app.route('/')
def index():
    return render_template('index.html')

# Ruta de ejemplo para conexión a base de datos
@app.route('/datos')
def datos():
    conn = sqlite3.connect('dashboard.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM kpis')
    resultados = cursor.fetchall()
    conn.close()
    return {'resultados': resultados}

if __name__ == '__main__':
    app.run(debug=True)
