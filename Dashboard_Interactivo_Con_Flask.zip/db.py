
import sqlite3

def crear_base_datos():
    conn = sqlite3.connect('dashboard.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS kpis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            valor REAL NOT NULL
        )
    ''')
    # Insertar datos de ejemplo
    cursor.execute("INSERT INTO kpis (nombre, valor) VALUES ('CTR Facebook', 2.5)")
    cursor.execute("INSERT INTO kpis (nombre, valor) VALUES ('Tasa de Rebote', 65.0)")
    cursor.execute("INSERT INTO kpis (nombre, valor) VALUES ('Adquisición', 1234)")
    cursor.execute("INSERT INTO kpis (nombre, valor) VALUES ('Sentimiento Positivo', 78.9)")
    conn.commit()
    conn.close()

if __name__ == '__main__':
    crear_base_datos()
